export const generateSeoTitle = title => {
   return `${title} - Project name`
}
