# Astro Starter TEMPLATE

## 🚀 Project Structure

Inside my Astro project, you'll see the following folders and files:

```text
├── .github/workflows/deploy.yml - CI/CD for project, deploy at another github repo
├── .vscode/ (snippets, vscode configuration)
├── public/js/
│   ├──data
│   │   └──test.json
│   └──index.js
│
├── src
│   ├── assets
│   │   ├── icons (.svg)
│   │   └── images (.png, .jpg, ...)
│   │  
│   ├── html
│   │   ├── components (small blocks)
│   │   ├── templates  (sections, feature)
│   │   ├── ui         (btns, custom lists)
│   │   └── utils      (connect libs...)
│   │  
│   ├── layouts
│   │   └── Layout.astro
│   └── pages
│       └── index.astro (or many pages)
├── prettierrc
├── format-dist.js - formating dist file
└── package.json
```

## 🧞 Commands

All commands are run from the root of the project, from a terminal:
| Command | Action |
| :--------------------- | :----------------------------------------------- |
| `npm install` | Installs dependencies |
| `npm run dev` | Starts local dev server at `localhost:4321` |
| `npm run build` | Build your production site to `./dist/` |
| `npm run preview` | Preview your build locally, before deploying |
| `npm run format:dist` | Run formatting for folder dist |
| `npm run serve` | runs the build and formats the build version of the files. |

## Aliases

| Allias         | path                     |
| :------------- | :----------------------- |
| `@components/` | "./src/html/components/" |
| `@components/` | "./src/html/components/" |
| `@templates/`  | "./src/html/templates/"  |
| `@ui/`         | "./src/html/ui/"         |
| `@layouts/`    | "./src/layouts/"         |
| `@html/`       | "./src/html/"            |
| `@assets/`     | "./src/assets/"          |
| `@icons/`      | "./src/assets/icons"     |
| `@images/`     | "./src/assets/images"    |
| `@public/ `    | "./public/"              |

## CI/CD

1. Create personal token
   [gitHub](https://github.com/settings/tokens)

   scope - ✅ repo all

2. Connect personal token
   https://github.com/your-name/your-deploy-repository/settings/secrets/actions

   > click the button "new repository secret"

   > name - DEPLOY_TOKEN

   > value - your token, which was created in step 1

3. .github/workflows/deploy.yml
   change

   > external_repository: your-username/your-deploy-repository

4. git push
